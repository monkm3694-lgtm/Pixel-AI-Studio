package com.pixelai.studio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF201A38)
private val Purple = Color(0xFF7557F6)
private val Pink = Color(0xFFFF5C9A)
private val Cyan = Color(0xFF28BFD0)
private val Canvas = Color(0xFFF7F5FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PixelStudioApp() }
    }
}

@Composable
private fun PixelStudioApp() {
    var tab by remember { mutableStateOf("Home") }
    var mode by remember { mutableStateOf("Text to Image") }
    var prompt by remember { mutableStateOf("") }
    var creations by remember { mutableStateOf(listOf<String>()) }
    var notice by remember { mutableStateOf("") }

    MaterialTheme(colorScheme = lightColorScheme(primary = Purple, background = Canvas, surface = Color.White)) {
        Scaffold(
            containerColor = Canvas,
            bottomBar = {
                NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
                    listOf(
                        Triple("Home", Icons.Default.Home, "Home"),
                        Triple("Create", Icons.Default.AutoAwesome, "Create"),
                        Triple("My Work", Icons.Default.Collections, "My Work"),
                        Triple("Profile", Icons.Default.Person, "Profile")
                    ).forEach { (label, icon, route) ->
                        NavigationBarItem(selected = tab == route, onClick = { tab = route }, icon = { Icon(icon, null) }, label = { Text(label, fontSize = 10.sp) })
                    }
                }
            }
        ) { padding ->
            when (tab) {
                "Create" -> CreatePage(Modifier.padding(padding), mode, { mode = it }, prompt, { prompt = it }, notice, {
                    if (prompt.isBlank()) notice = "Write a prompt first."
                    else notice = "UI demo only: connect an AI generation server to create real files."
                })
                "My Work" -> MyWorkPage(Modifier.padding(padding), creations)
                "Profile" -> ProfilePage(Modifier.padding(padding))
                else -> HomePage(Modifier.padding(padding), onCreate = { tab = "Create"; notice = "" }, onMode = { mode = it; tab = "Create"; notice = "" })
            }
        }
    }
}

@Composable
private fun HomePage(modifier: Modifier, onCreate: () -> Unit, onMode: (String) -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(top = 24.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("PIXEL AI STUDIO", color = Purple, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                    Text("Create beyond\nimagination.", color = Ink, fontSize = 32.sp, lineHeight = 37.sp, fontWeight = FontWeight.ExtraBold)
                }
                Box(Modifier.size(52.dp).background(Color.White, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.AutoAwesome, null, tint = Pink, modifier = Modifier.size(28.dp))
                }
            }
        }
        item {
            Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Purple, Pink, Color(0xFFFFB45C))), RoundedCornerShape(28.dp)).padding(22.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("YOUR AI CREATIVE LAB", color = Color.White.copy(.85f), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                    Text("Turn your ideas into\namazing visuals", color = Color.White, fontSize = 26.sp, lineHeight = 31.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Photos • Videos • Creative edits", color = Color.White.copy(.9f), fontSize = 13.sp)
                    Button(onClick = onCreate, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Purple), shape = RoundedCornerShape(14.dp)) {
                        Text("Start creating", fontWeight = FontWeight.Bold); Spacer(Modifier.width(8.dp)); Icon(Icons.Default.ArrowForward, null)
                    }
                }
            }
        }
        item { Text("Create with AI", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                FeatureCard("Text to Image", "Describe it. Imagine it.", Icons.Default.Image, Purple) { onMode("Text to Image") }
                FeatureCard("Image to Video", "Bring a still photo to life.", Icons.Default.Movie, Pink) { onMode("Image to Video") }
                FeatureCard("Text to Video", "Turn a prompt into a video.", Icons.Default.Videocam, Cyan) { onMode("Text to Video") }
                FeatureCard("AI Photo Editor", "Enhance and restyle a photo.", Icons.Default.AutoFixHigh, Color(0xFFFFA64D)) { onMode("Photo Editor") }
            }
        }
        item {
            Surface(color = Color(0xFFFFF2F7), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, null, tint = Pink)
                    Spacer(Modifier.width(10.dp))
                    Text("Preview build: real AI generation will work after a secure AI backend is connected.", color = Ink, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun FeatureCard(title: String, subtitle: String, icon: ImageVector, tint: Color, onClick: () -> Unit) {
    Surface(shape = RoundedCornerShape(20.dp), color = Color.White, shadowElevation = 2.dp, modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).background(tint.copy(alpha = .13f), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = tint, modifier = Modifier.size(27.dp)) }
            Column(Modifier.weight(1f).padding(start = 14.dp)) {
                Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(subtitle, color = Color.Gray, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Color.LightGray)
        }
    }
}

@Composable
private fun CreatePage(modifier: Modifier, mode: String, onMode: (String) -> Unit, prompt: String, onPrompt: (String) -> Unit, notice: String, onGenerate: () -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(top = 24.dp, bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Text("Create something magical", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
            Text("Choose a tool and describe what you want.", color = Color.Gray, fontSize = 13.sp)
        }
        item {
            Text("CREATION MODE", color = Purple, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.2.sp)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Text to Image", "Image to Video", "Text to Video", "Photo Editor").forEach { option ->
                    Surface(color = if (mode == option) Color(0xFFF0ECFF) else Color.White, shape = RoundedCornerShape(14.dp), border = androidx.compose.foundation.BorderStroke(if (mode == option) 1.dp else 0.5.dp, if (mode == option) Purple else Color(0xFFE9E6F0)), modifier = Modifier.fillMaxWidth().clickable { onMode(option) }) {
                        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(when (option) { "Text to Video", "Image to Video" -> Icons.Default.Movie; "Photo Editor" -> Icons.Default.AutoFixHigh; else -> Icons.Default.Image }, null, tint = Purple)
                            Text(option, Modifier.weight(1f).padding(start = 10.dp), color = Ink, fontWeight = FontWeight.SemiBold)
                            if (mode == option) Icon(Icons.Default.CheckCircle, null, tint = Purple)
                        }
                    }
                }
            }
        }
        item {
            Text("YOUR PROMPT", color = Purple, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.2.sp)
            OutlinedTextField(value = prompt, onValueChange = onPrompt, modifier = Modifier.fillMaxWidth().heightIn(min = 145.dp), placeholder = { Text("A cinematic portrait in a field of flowers, golden hour lighting...") }, shape = RoundedCornerShape(18.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Purple, unfocusedBorderColor = Color(0xFFE2DEED)))
            Text("Tip: describe the subject, style, lighting, colors and camera angle.", color = Color.Gray, fontSize = 11.sp)
        }
        item {
            Button(onClick = onGenerate, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text("Generate", fontWeight = FontWeight.Bold)
            }
            if (notice.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Surface(color = Color(0xFFFFF4E8), shape = RoundedCornerShape(14.dp)) { Text(notice, Modifier.padding(13.dp), color = Color(0xFF87521B), fontSize = 12.sp) }
            }
        }
    }
}

@Composable
private fun MyWorkPage(modifier: Modifier, creations: List<String>) {
    Column(modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(84.dp).background(Color(0xFFEFEAFF), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Collections, null, tint = Purple, modifier = Modifier.size(38.dp)) }
        Spacer(Modifier.height(18.dp))
        Text("Your creations", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text(if (creations.isEmpty()) "Your generated photos and videos will appear here once AI generation is connected." else creations.joinToString("\n"), color = Color.Gray, textAlign = TextAlign.Center)
    }
}

@Composable
private fun ProfilePage(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Your profile", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        Surface(color = Color.White, shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.AutoAwesome, null, tint = Purple); Spacer(Modifier.width(10.dp)); Text("Pixel AI Studio", fontWeight = FontWeight.Bold, color = Ink) }
                Text("Version 1.0 • Android preview", color = Color.Gray, fontSize = 12.sp)
                Divider()
                Text("Free-to-use concept. AI generation requires a backend and an AI model provider.", color = Color.Gray, fontSize = 13.sp)
            }
        }
    }
}
