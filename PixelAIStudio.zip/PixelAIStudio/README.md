# Pixel AI Studio — Android + backend starter

## Android
1. Install Android Studio and open this `PixelAIStudio` folder.
2. Replace `API_BASE_URL` in `app/build.gradle.kts` with your deployed HTTPS backend URL.
3. Sync Gradle and run on a device/emulator.

## Backend
1. Install Python 3.10+.
2. `cd backend`
3. `python -m venv .venv` and activate it.
4. `pip install -r requirements.txt`
5. `uvicorn main:app --reload`
6. Check `/health`.

## Important status
This package includes the Android UI prototype and a FastAPI backend scaffold. Real AI image/video generation is NOT active yet: `/generate` returns HTTP 501 until a real image/video provider adapter is implemented. Put provider keys only in server environment variables, never in the Android app.

Truly unlimited AI generation is not inherently free: GPU inference, hosting, storage and bandwidth have costs. A free-to-user service needs sponsored/self-hosted compute or a provider plan that explicitly covers usage. Do not promise unlimited service until that infrastructure is funded and tested.

## Before public launch
Implement provider jobs and polling, result storage, authentication, rate limiting, upload validation, moderation, deletion controls and cost monitoring.\n