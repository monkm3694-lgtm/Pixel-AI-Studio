import os
from typing import Literal, Optional
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI(title="Pixel AI Studio API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "*").split(","),
    allow_credentials=False, allow_methods=["GET", "POST"], allow_headers=["*"],
)

class GenerateRequest(BaseModel):
    mode: Literal["Text to Image", "Image to Video", "Text to Video", "Photo Editor"]
    prompt: str = Field(min_length=3, max_length=2000)
    source_image_url: Optional[str] = None

@app.get("/health")
def health():
    return {"ok": True, "service": "Pixel AI Studio API"}

@app.post("/generate")
def generate(request: GenerateRequest):
    image_key = os.getenv("IMAGE_PROVIDER_API_KEY")
    video_key = os.getenv("VIDEO_PROVIDER_API_KEY")
    if request.mode in ("Text to Image", "Photo Editor") and not image_key:
        raise HTTPException(503, "Image provider is not configured on the server.")
    if request.mode in ("Image to Video", "Text to Video") and not video_key:
        raise HTTPException(503, "Video provider is not configured on the server.")
    # Add the selected provider's real job-creation adapter here.
    # No fake success is returned and no API keys are exposed to Android.
    raise HTTPException(501, "Provider adapter is not implemented yet.")\n